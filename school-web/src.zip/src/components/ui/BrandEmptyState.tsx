import { cn } from "@/lib/utils";
import BrandButton from "./BrandButton";

/* ─── Types ─── */
interface BrandEmptyStateProps {
  icon: string;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
    variant?: "primary" | "secondary";
  };
  size?: "sm" | "md" | "lg";
}

const iconContainer: Record<string, string> = {
  sm: "w-16 h-16 text-3xl",
  md: "w-20 h-20 text-4xl",
  lg: "w-28 h-28 text-5xl",
};

const titleSize: Record<string, string> = {
  sm: "text-base",
  md: "text-lg",
  lg: "text-xl",
};

/* ─── Main Component ─── */
export default function BrandEmptyState({
  icon,
  title,
  description,
  action,
  size = "md",
}: BrandEmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-6">
      <div
        className={cn(
          "rounded-full bg-brand-purple/8 flex items-center justify-center mb-4 mx-auto",
          iconContainer[size]
        )}
      >
        {icon}
      </div>
      <h3 className={cn("font-display font-bold text-ink-dark mt-1", titleSize[size])}>{title}</h3>
      {description && (
        <p className="text-ink-muted text-sm mt-2 max-w-xs leading-relaxed">{description}</p>
      )}
      {action && (
        <div className="mt-6">
          <BrandButton
            variant={action.variant ?? "primary"}
            onClick={action.onClick}
          >
            {action.label}
          </BrandButton>
        </div>
      )}
    </div>
  );
}
