import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const gradientMap: Record<string, string> = {
  purple: "gradient-purple",
  pink: "gradient-pink",
  mint: "gradient-mint",
  amber: "gradient-purple",
  sky: "gradient-ocean",
  orange: "gradient-pink",
};

const customGradientMap: Record<string, string> = {
  amber: "background: linear-gradient(135deg, #FFB347 0%, var(--color-accent, #FF6584) 100%)",
  orange: "background: linear-gradient(135deg, #FB923C 0%, #FFB347 100%)",
};

interface Trend {
  value: number;
  label: string;
  up: boolean;
}

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  gradient: "purple" | "pink" | "mint" | "amber" | "sky" | "orange";
  trend?: Trend;
  className?: string;
}

export default function StatCard({
  title,
  value,
  subtitle,
  icon,
  gradient,
  trend,
  className,
}: StatCardProps) {
  const isCustom = gradient === "amber" || gradient === "orange";

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl p-6 text-white",
        !isCustom && gradientMap[gradient],
        className
      )}
      style={isCustom ? { background: customGradientMap[gradient] } : undefined}
    >
      {/* Decorative circle */}
      <div className="absolute -bottom-6 -right-6 h-32 w-32 rounded-full bg-white/10" />

      {/* Icon box */}
      <div className="ml-auto flex h-10 w-10 items-center justify-center rounded-xl bg-white/20">
        {icon}
      </div>

      {/* Title */}
      <p className="mt-3 text-sm opacity-80">{title}</p>

      {/* Value */}
      <p className="font-display text-3xl font-bold">{value}</p>

      {/* Subtitle */}
      {subtitle && <p className="mt-1 text-xs opacity-70">{subtitle}</p>}

      {/* Trend badge */}
      {trend && (
        <div className="mt-3 inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-0.5 text-xs font-semibold">
          <span>{trend.up ? "↑" : "↓"}</span>
          <span>{trend.value}%</span>
          <span className="opacity-80">{trend.label}</span>
        </div>
      )}
    </div>
  );
}
