import { cn } from "@/lib/utils";

const colorMap: Record<string, string> = {
  purple: "bg-brand-purple text-white",
  pink: "bg-brand-pink text-white",
  mint: "bg-brand-mint text-white",
  amber: "bg-brand-amber text-white",
  red: "bg-brand-red text-white",
  sky: "bg-brand-sky text-white",
  lavender: "bg-brand-lavender text-white",
};

interface BrandBadgeProps {
  label: string;
  color: "purple" | "pink" | "mint" | "amber" | "red" | "sky" | "lavender";
  className?: string;
}

export default function BrandBadge({ label, color, className }: BrandBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold",
        colorMap[color],
        className
      )}
    >
      {label}
    </span>
  );
}
