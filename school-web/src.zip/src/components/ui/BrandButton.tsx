import { type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

/* ─── Types ─── */
interface BrandButtonProps {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "outline";
  size?: "sm" | "md" | "lg";
  isLoading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  type?: "button" | "submit" | "reset";
  className?: string;
  fullWidth?: boolean;
}

const sizeClasses: Record<string, string> = {
  sm: "px-3 py-1.5 text-xs rounded-lg gap-1.5",
  md: "px-4 py-2.5 text-sm rounded-xl gap-2",
  lg: "px-6 py-3 text-base rounded-xl gap-2.5",
};

const variantClasses: Record<string, string> = {
  primary:
    "text-white font-semibold shadow-card hover:shadow-glow hover:scale-[1.02] active:scale-[0.98] transition-all duration-200",
  secondary:
    "bg-white border-2 border-brand-purple text-brand-purple font-semibold hover:bg-brand-purple/5 shadow-card transition-all duration-200",
  outline:
    "bg-white border-2 border-brand-purple text-brand-purple font-semibold hover:bg-brand-purple/5 shadow-card transition-all duration-200",
  ghost:
    "bg-transparent text-ink-muted font-medium hover:bg-surface-bg text-ink-dark transition-all duration-200",
  danger:
    "bg-brand-red text-white font-semibold hover:brightness-110 shadow-card transition-all duration-200",
};

/* ─── Main Component ─── */
export default function BrandButton({
  children,
  variant = "primary",
  size = "md",
  isLoading,
  leftIcon,
  rightIcon,
  disabled,
  onClick,
  type = "button",
  className,
  fullWidth,
}: BrandButtonProps) {
  const isDisabled = disabled || isLoading;

  const spinnerColor =
    variant === "primary" || variant === "danger"
      ? "border-white/30 border-t-white"
      : "border-brand-purple/30 border-t-brand-purple";

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={isDisabled}
      className={cn(
        "inline-flex items-center justify-center",
        sizeClasses[size],
        variantClasses[variant],
        variant === "primary" && "gradient-purple",
        fullWidth && "w-full",
        isDisabled && "opacity-50 cursor-not-allowed pointer-events-none",
        className
      )}
    >
      {isLoading ? (
        <>
          <Loader2 className={cn("h-4 w-4 animate-spin", spinnerColor)} />
          <span>Loading...</span>
        </>
      ) : (
        <>
          {leftIcon}
          {children}
          {rightIcon}
        </>
      )}
    </button>
  );
}
