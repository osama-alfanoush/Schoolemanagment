import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const gradientMap: Record<string, string> = {
  purple: "gradient-purple text-white",
  pink: "gradient-pink text-white",
  mint: "gradient-mint text-white",
  sunset: "gradient-sunset text-white",
  ocean: "gradient-ocean text-white",
};

interface BrandCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  gradient?: "purple" | "pink" | "mint" | "sunset" | "ocean";
  glass?: boolean;
  onClick?: () => void;
}

export default function BrandCard({
  children,
  className,
  hover = false,
  gradient,
  glass = false,
  onClick,
}: BrandCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-2xl p-6 shadow-card",
        // Base style: white bg unless gradient or glass
        !gradient && !glass && "bg-white",
        // Gradient overrides background + text
        gradient && gradientMap[gradient],
        // Glass style
        glass && "glass-card",
        // Hover lift effect
        hover &&
        "transition-all duration-300 cursor-pointer hover:shadow-hover hover:-translate-y-1",
        className
      )}
    >
      {children}
    </div>
  );
}
